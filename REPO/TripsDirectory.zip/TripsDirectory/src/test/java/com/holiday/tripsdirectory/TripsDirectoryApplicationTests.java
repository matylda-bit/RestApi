package com.holiday.tripsdirectory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripsDirectoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
