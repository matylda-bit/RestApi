package com.holiday.tripsdirectory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripsDirectoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(TripsDirectoryApplication.class, args);
    }

}
